myApp.controller('MeetingsController', ['$scope', function($scope) {

}]);